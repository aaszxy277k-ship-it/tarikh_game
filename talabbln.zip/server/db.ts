import { and, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { answers, attempts, contentSections, exams, InsertUser, questions, siteServices, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "phone", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      const value = user[field] ?? null;
      values[field] = value;
      updateSet[field] = value;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export function normalizePhone(value: string) {
  const arabicDigits = value.replace(/[٠-٩]/g, digit => String(digit.charCodeAt(0) - 1632));
  return arabicDigits.replace(/[^0-9]/g, "");
}

const starterSlug = "history-second-secondary";

const starterQuestions = [
  { type: "mcq" as const, prompt: "الأثر الناتج عن فقدان السلطة هو؟", options: ["تنامي دورها على المستوى الإقليمي", "امتلاكها حق تقرير مصيرها", "تحقيق حالة من الأمن والاستقرار", "تحولها إلى كيان تابع غير مستقل"] },
  { type: "mcq" as const, prompt: "أي من الآتي يعد مخالفة صريحة للمادة الأولى من دستور مصر 2014م؟", options: ["المشاركة الفعالة في قضايا الأمة العربية", "التنازل عن جزء من جغرافية الدولة البرية والبحرية", "صيانة الدولة ضد أي إملاء خارجي", "إعلاء مبدأ المواطنة ونشر العدالة"] },
  { type: "mcq" as const, prompt: "قامت وزارة التربية والتعليم بتعميم دراسة التاريخ على جميع مسارات البكالوريا، ما هدف الدولة من هذا الإجراء؟", options: ["ترويج جيل يحاكي القدم والثقافة الغربية", "الحفاظ على الهوية الوطنية", "إثارة النزاعات الفكرية في المناهج الدراسية", "الرغبة في دخول أهم المؤسسات العسكرية"] },
  { type: "mcq" as const, prompt: "عندما تعرضت مصر للعدوان الثلاثي عام 1956م، شارك أبناء الشعب المصري في مقاومة المعتدين مما أدى إلى إفشال أهداف المؤامرة، نستدل من الحدث على أحد صور أدوار الشعب وهي:", options: ["دعم أمن الدولة واستقرارها من خلال احترام القوانين", "التمسك بكامل التراب الوطني والدفاع عن الدولة", "الالتزام بدفع الضرائب لتمويل المشروعات العامة", "المشاركة السياسية والرغبة في اختيار السلطة"] },
  { type: "mcq" as const, prompt: "عرفت الحدود المصرية بأنها الأكثر ثباتاً بين دول العالم على مر التاريخ ويرجع ذلك إلى عدة عوامل منها:", options: ["وعي الشعب المصري بجغرافية بلاده", "التكدس السكاني حول الوادي الضيق", "سيطرة السمة الطبيعية على أغلبها", "قوة الجيش المصري وسياساته الرشيدة"] },
  { type: "mcq" as const, prompt: "يحمل المجال الجوي للدولة بعدين أحدهما مدني والآخر عسكري وتمارس السلطة سيادتها عليهما، أي من الآتي يشير إلى دور السلطة في تنظيم النشاط المدني؟", options: ["تأهب الدفاع الجوي لأي تهديد محتمل", "إدارة حركة الطيران والرحلات الجوية", "نشاط الرادارات والتقاط أي اختراق للمجال الجوي", "تنشيط نقاط المراقبة الحدودية"] },
  { type: "mcq" as const, prompt: "ترتبط ممارسة الدولة لسيادتها على المجال الجوي:", options: ["ثبات واستقرار حدودها السياسية في المقام الأول", "الاعتراف الدولي بحدودها السياسية عبر العصور القديمة", "تحديد وتثبيت معالم شطر المقاطعات الإدارية الداخلية", "النفوذ القانوني الممتد فوق حيزها الأرضي والتاريخية"] },
  { type: "mcq" as const, prompt: "من الضروري تواجد قوات مسلحة على أعلى جاهزية في الدولة لتنفيذ أهداف أساسية ومنها:", options: ["حل النزاعات المدنية وتحقيق الأمن الاجتماعي", "صيانة الحيز الجغرافي للدولة وحماية مكتسباتها", "جمع الضرائب ومراعاة تطبيق القانون", "التدخل في شئون وسيادة الدول المجاورة"] },
  { type: "essay" as const, prompt: "ما مفهوم الدولة؟", options: [] },
  { type: "essay" as const, prompt: "ما هي أركان الدولة؟ مع ذكر مثال.", options: [] },
  { type: "essay" as const, prompt: "هناك ارتباط وثيق بين الحكومة المركزية القوية وسيادتها، اكتب رأياً داعماً.", options: [] },
  { type: "essay" as const, prompt: "وفقاً لأفكار جمال حمدان حول موقع مصر الجغرافي، ماذا يحدث إذا لم يكن هناك نهر النيل؟", options: [] },
  { type: "essay" as const, prompt: "قال الفيلسوف توماس هوبز عبارته الشهيرة «حرب الكل ضد الكل» واصفاً حالة البشر الأولى، اكتب تحليلاً عن الأسباب التي ساهمت في تلافي هذا الوضع في مصر.", options: [] },
];

export async function ensureStarterExam() {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select({ id: exams.id }).from(exams).where(eq(exams.slug, starterSlug)).limit(1);
  if (existing.length > 0) return;

  await db.insert(exams).values({
    slug: starterSlug,
    title: "السلطة والسيادة والدولة",
    subject: "التاريخ",
    grade: "الصف الثاني الثانوي",
    description: "امتحان إلكتروني في مفاهيم الدولة والسلطة والسيادة، يتضمن اختيارًا من متعدد وأسئلة مقالية.",
    durationMinutes: 35,
    maxAttempts: 2,
    isPublished: false,
    shuffleQuestions: false,
    showAnswers: true,
  });
  const exam = await db.select({ id: exams.id }).from(exams).where(eq(exams.slug, starterSlug)).limit(1);
  if (exam.length === 0) return;
  await db.insert(questions).values(starterQuestions.map((question, index) => ({
    examId: exam[0].id,
    type: question.type,
    prompt: question.prompt,
    options: question.options.length ? JSON.stringify(question.options) : null,
    correctAnswer: null,
    points: question.type === "essay" ? 5 : 1,
    sortOrder: index,
  })));
}

export async function ensureStarterContent() {
  const db = await getDb();
  if (!db) return;
  const sectionRows = await db.select({ id: contentSections.id }).from(contentSections).limit(1);
  if (sectionRows.length === 0) {
    const sections = [
      ["الثانوية العامة", "thanaweya-amma", "مواد ومراجعات الثانوية العامة", "GraduationCap"],
      ["البكالوريا المصرية", "egyptian-baccalaureate", "مسارات البكالوريا المصرية ومواردها", "Landmark"],
      ["الصف الأول الثانوي", "grade-one-secondary", "محتوى الصف الأول الثانوي", "BookOpen"],
      ["الصف الثاني الثانوي", "grade-two-secondary", "محتوى الصف الثاني الثانوي", "BookOpenCheck"],
      ["الصف الثالث الثانوي", "grade-three-secondary", "محتوى الصف الثالث الثانوي", "Trophy"],
      ["المراجعات والملخصات", "reviews-and-summaries", "مراجعات نهائية ومذكرات منظمة", "NotebookPen"],
      ["بنك الأسئلة", "question-bank", "تدريبات وأسئلة للمراجعة", "ListChecks"],
      ["الامتحانات الإلكترونية", "online-exams", "اختبارات تقيس تقدمك", "TimerReset"],
      ["نماذج الوزارة والواجبات", "ministry-and-homework", "نماذج وتدريبات إضافية", "FileText"],
    ];
    await db.insert(contentSections).values(sections.map(([title, slug, description, icon], index) => ({ title, slug, description, icon, displayOrder: index, isVisible: true })));
  }
  const serviceRows = await db.select({ id: siteServices.id }).from(siteServices).limit(1);
  if (serviceRows.length === 0) {
    const services = [
      ["جدول المذاكرة", "نظّم وقتك بخطة مذاكرة واضحة", "CalendarDays"],
      ["حاسبة الدرجات", "احسب نسبتك المئوية بسهولة", "Calculator"],
      ["متابعة المستوى", "اعرف تقدمك من خلال نتائجك", "TrendingUp"],
      ["دليل الكليات", "استكشف مساراتك التعليمية القادمة", "School"],
      ["المساعد التعليمي", "مساعد عربي لمراجعة دروسك", "Bot"],
      ["لوحة الشرف", "احتفل بتقدم طلاب البلينا", "Medal"],
      ["مجتمع الطلاب", "مساحة للتعلم والمشاركة الإيجابية", "Users"],
    ];
    await db.insert(siteServices).values(services.map(([title, description, icon], index) => ({ title, description, icon, displayOrder: index, isVisible: true })));
  }
  const oldLibraryRows = await db.select({ id: siteServices.id }).from(siteServices).where(eq(siteServices.title, "مكتبة كليوباترا")).limit(1);
  if (oldLibraryRows.length > 0) {
    await db.update(siteServices).set({ title: "مكتبة البلينا", description: "مكتبة البلينا، وجهتك للحصول على المستلزمات والأدوات التعليمية والكتب والمراجع الدراسية. نوفر للطلاب مساحة للتعرّف على خدمات المكتبة وما تقدمه من احتياجات تساعدهم في رحلتهم التعليمية.", link: "#blina-library" }).where(eq(siteServices.id, oldLibraryRows[0].id));
  }
  const libraryRows = await db.select({ id: siteServices.id }).from(siteServices).where(eq(siteServices.title, "مكتبة البلينا")).limit(1);
  if (libraryRows.length > 0) {
    await db.update(siteServices).set({ link: "#blina-library" }).where(eq(siteServices.id, libraryRows[0].id));
  }
  if (oldLibraryRows.length === 0 && libraryRows.length === 0) {
    await db.insert(siteServices).values({
      title: "مكتبة البلينا",
      description: "مكتبة البلينا، وجهتك للحصول على المستلزمات والأدوات التعليمية والكتب والمراجع الدراسية. نوفر للطلاب مساحة للتعرّف على خدمات المكتبة وما تقدمه من احتياجات تساعدهم في رحلتهم التعليمية.",
      icon: "BookOpen",
      link: "#blina-library",
      displayOrder: 7,
      isVisible: true,
    });
  }
}

export async function recalculateAttempt(attemptId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const attemptRows = await db.select({ examId: attempts.examId }).from(attempts).where(eq(attempts.id, attemptId)).limit(1);
  if (attemptRows.length === 0) throw new Error("Attempt is not available");
  const questionRows = await db.select({ id: questions.id, points: questions.points }).from(questions).where(eq(questions.examId, attemptRows[0].examId));
  const rows = await db.select({
    answer: answers,
    question: questions,
  }).from(answers).innerJoin(questions, eq(answers.questionId, questions.id)).where(eq(answers.attemptId, attemptId));
  const score = rows.reduce((sum, row) => sum + (row.answer.pointsAwarded ?? 0), 0);
  const maxScore = questionRows.reduce((sum, row) => sum + row.points, 0);
  const percentage = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;
  await db.update(attempts).set({ score, maxScore, percentage }).where(eq(attempts.id, attemptId));
  return { score, maxScore, percentage };
}

export function isSameUser(userId: number, attemptUserId: number) {
  return userId === attemptUserId;
}
