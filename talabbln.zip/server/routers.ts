import { and, asc, desc, eq, like, sql } from "drizzle-orm";
import { z } from "zod";
import { announcements, answers, attempts, certificates, contentSections, exams, learningResources, questions, siteServices, users } from "../drizzle/schema";
import * as dbLib from "./db";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { sdk } from "./_core/sdk";
import { invokeLLM } from "./_core/llm";

const examInput = z.object({
  title: z.string().min(2),
  subject: z.string().min(2),
  grade: z.string().min(2),
  description: z.string().optional().nullable(),
  durationMinutes: z.number().int().min(1).max(300),
  maxAttempts: z.number().int().min(1).max(20),
  isPublished: z.boolean(),
  shuffleQuestions: z.boolean(),
  showAnswers: z.boolean(),
});

const questionInput = z.object({
  examId: z.number().int().positive(),
  type: z.enum(["mcq", "true_false", "essay"]),
  prompt: z.string().min(2),
  options: z.array(z.string()).default([]),
  correctAnswer: z.string().optional().nullable(),
  points: z.number().int().min(0).max(100),
  sortOrder: z.number().int().min(0),
});

const sectionInput = z.object({ title: z.string().trim().min(2), slug: z.string().trim().min(2).regex(/^[a-z0-9-]+$/), description: z.string().optional().nullable(), icon: z.string().trim().min(2).max(40), displayOrder: z.number().int().min(0), isVisible: z.boolean() });
const serviceInput = z.object({ title: z.string().trim().min(2), description: z.string().optional().nullable(), icon: z.string().trim().min(2).max(40), link: z.string().optional().nullable(), displayOrder: z.number().int().min(0), isVisible: z.boolean() });
const announcementInput = z.object({ title: z.string().trim().min(2), body: z.string().trim().min(2), link: z.string().optional().nullable(), isPublished: z.boolean() });
const resourceInput = z.object({ title: z.string().trim().min(2), description: z.string().optional().nullable(), kind: z.string().trim().min(2), system: z.string().optional().nullable(), grade: z.string().optional().nullable(), subject: z.string().optional().nullable(), url: z.string().optional().nullable(), isPublished: z.boolean() });
const aiMessageInput = z.object({ role: z.enum(["user", "assistant"]), content: z.string().trim().min(1).max(6000) });

function parseOptions(value: string | null) {
  if (!value) return [] as string[];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter(item => typeof item === "string") : [];
  } catch {
    return [] as string[];
  }
}

function publicQuestion(question: typeof questions.$inferSelect, includeAnswer = false) {
  return {
    ...question,
    options: parseOptions(question.options),
    correctAnswer: includeAnswer ? question.correctAnswer : null,
  };
}

async function getDatabase() {
  const database = await dbLib.getDb();
  if (!database) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "قاعدة البيانات غير متاحة حاليًا" });
  return database;
}

async function getExamWithQuestions(examId: number, includeAnswers = false, publishedOnly = false) {
  const database = await getDatabase();
  const examRows = await database.select().from(exams).where(eq(exams.id, examId)).limit(1);
  if (examRows.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "الامتحان غير موجود" });
  if (publishedOnly && !examRows[0].isPublished) throw new TRPCError({ code: "NOT_FOUND", message: "الامتحان غير متاح" });
  const questionRows = await database.select().from(questions).where(eq(questions.examId, examId)).orderBy(questions.sortOrder, questions.id);
  if (examRows[0].shuffleQuestions) questionRows.sort(() => Math.random() - 0.5);
  return { exam: examRows[0], questions: questionRows.map(question => publicQuestion(question, includeAnswers)) };
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    register: publicProcedure.input(z.object({ name: z.string().trim().min(2, "اكتب الاسم بالكامل").max(120), phone: z.string().min(8, "رقم الهاتف غير صحيح").max(24, "رقم الهاتف غير صحيح") })).mutation(async ({ ctx, input }) => {
      const phone = dbLib.normalizePhone(input.phone);
      if (phone.length < 10 || phone.length > 15) throw new TRPCError({ code: "BAD_REQUEST", message: "اكتب رقم هاتف صحيحًا من 10 إلى 15 رقمًا" });
      const openId = `phone_${phone}`;
      await dbLib.upsertUser({ openId, name: input.name.trim(), phone, email: null, loginMethod: "phone", lastSignedIn: new Date() });
      const sessionToken = await sdk.createSessionToken(openId, { name: input.name.trim(), expiresInMs: ONE_YEAR_MS });
      ctx.res.cookie(COOKIE_NAME, sessionToken, { ...getSessionCookieOptions(ctx.req), maxAge: ONE_YEAR_MS });
      return await dbLib.getUserByOpenId(openId);
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  exams: router({
    listPublic: publicProcedure.query(async () => {
      const database = await getDatabase();
      const rows = await database.select().from(exams).where(eq(exams.isPublished, true)).orderBy(desc(exams.createdAt));
      const counts = await Promise.all(rows.map(async exam => {
        const questionRows = await database.select({ id: questions.id }).from(questions).where(eq(questions.examId, exam.id));
        return { ...exam, questionCount: questionRows.length };
      }));
      return counts;
    }),
    get: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => getExamWithQuestions(input.id, false, true)),
  }),

  content: router({
    home: publicProcedure.query(async () => {
      const database = await getDatabase();
      const [sections, services, news, resources] = await Promise.all([
        database.select().from(contentSections).where(eq(contentSections.isVisible, true)).orderBy(asc(contentSections.displayOrder), asc(contentSections.id)),
        database.select().from(siteServices).where(eq(siteServices.isVisible, true)).orderBy(asc(siteServices.displayOrder), asc(siteServices.id)),
        database.select().from(announcements).where(eq(announcements.isPublished, true)).orderBy(desc(announcements.createdAt)).limit(6),
        database.select().from(learningResources).where(eq(learningResources.isPublished, true)).orderBy(desc(learningResources.createdAt)).limit(12),
      ]);
      return { sections, services, announcements: news, resources };
    }),
  }),

  ai: router({
    chat: publicProcedure.input(z.object({ messages: z.array(aiMessageInput).min(1).max(20) })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        model: "gpt-5-mini",
        maxCompletionTokens: 900,
        messages: [
          {
            role: "system",
            content: "أنت رفيقك، مساعد تعليمي عربي ودود داخل منصة طلاب البلينا لطلاب المرحلة الثانوية في مصر. مهمتك شرح الدروس والمناهج، حل الأسئلة مع توضيح الخطوات، تلخيص المحتوى، إنشاء أسئلة تدريبية، ومساعدة الطالب على الاستعداد للامتحان. ابدأ الإجابة مباشرة وبالعربية البسيطة، ونظّم الشرح بعناوين ونقاط وأمثلة عند الحاجة. إذا كان السؤال غامضًا فاسأل سؤالًا توضيحيًا واحدًا. لا تخترع إجابات نموذجية لامتحانات المنصة ولا تدّعي أنك معلم رسمي؛ نبّه الطالب بلطف عندما تحتاج المعلومة إلى مراجعة كتابه أو مدرسه. لا تساعد على الغش أثناء امتحان جارٍ: قدّم شرحًا للمفهوم بدل اختيار الإجابة نيابة عن الطالب. كن مشجعًا ومختصرًا بما يكفي، وعمليًا في كل رد.",
          },
          ...input.messages,
        ],
      });
      const content = response.choices?.[0]?.message?.content;
      const answer = typeof content === "string" ? content : Array.isArray(content) ? content.filter((item): item is { type: "text"; text: string } => item.type === "text").map(item => item.text).join("\n") : "";
      if (!answer.trim()) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "لم يصل رد من رفيقك" });
      return { answer };
    }),
  }),

  student: router({
    dashboard: protectedProcedure.query(async ({ ctx }) => {
      const database = await getDatabase();
      const resultRows = await database.select({
        attempt: attempts,
        exam: exams,
      }).from(attempts).innerJoin(exams, eq(attempts.examId, exams.id)).where(eq(attempts.userId, ctx.user.id)).orderBy(desc(attempts.createdAt));
      return resultRows.map(row => ({ ...row.attempt, examTitle: row.exam.title, subject: row.exam.subject, grade: row.exam.grade }));
    }),
    leaderboard: protectedProcedure.input(z.object({ examId: z.number().int().positive() })).query(async ({ input }) => {
      const database = await getDatabase();
      const rows = await database.select({ attempt: attempts, user: users }).from(attempts).innerJoin(users, eq(attempts.userId, users.id)).where(and(eq(attempts.examId, input.examId), sql`${attempts.status} <> 'in_progress'`)).orderBy(desc(attempts.percentage), attempts.submittedAt).limit(20);
      return rows.map((row, index) => ({ rank: index + 1, name: row.user.name || "طالب", percentage: row.attempt.percentage, score: row.attempt.score, maxScore: row.attempt.maxScore }));
    }),
  }),

  attempts: router({
    start: protectedProcedure.input(z.object({ examId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const database = await getDatabase();
      const examRows = await database.select().from(exams).where(and(eq(exams.id, input.examId), eq(exams.isPublished, true))).limit(1);
      if (examRows.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "الامتحان غير متاح" });
      const existing = await database.select().from(attempts).where(and(eq(attempts.examId, input.examId), eq(attempts.userId, ctx.user.id), eq(attempts.status, "in_progress"))).limit(1);
      if (existing.length > 0) return { attempt: existing[0], ...(await getExamWithQuestions(input.examId, false, true)) };
      const history = await database.select({ id: attempts.id }).from(attempts).where(and(eq(attempts.examId, input.examId), eq(attempts.userId, ctx.user.id)));
      if (history.length >= examRows[0].maxAttempts) throw new TRPCError({ code: "FORBIDDEN", message: "لقد استنفدت عدد المحاولات المسموح بها لهذا الامتحان" });
      await database.insert(attempts).values({ examId: input.examId, userId: ctx.user.id, attemptNumber: history.length + 1, status: "in_progress", score: 0, maxScore: 0, percentage: 0 });
      const created = await database.select().from(attempts).where(and(eq(attempts.examId, input.examId), eq(attempts.userId, ctx.user.id), eq(attempts.status, "in_progress"))).orderBy(desc(attempts.id)).limit(1);
      return { attempt: created[0], ...(await getExamWithQuestions(input.examId, false, true)) };
    }),
    submit: protectedProcedure.input(z.object({ attemptId: z.number().int().positive(), answers: z.array(z.object({ questionId: z.number().int().positive(), answer: z.string().optional().nullable() })) })).mutation(async ({ ctx, input }) => {
      const database = await getDatabase();
      const attemptRows = await database.select().from(attempts).where(and(eq(attempts.id, input.attemptId), eq(attempts.userId, ctx.user.id))).limit(1);
      if (attemptRows.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "المحاولة غير موجودة" });
      const attempt = attemptRows[0];
      if (attempt.status !== "in_progress") throw new TRPCError({ code: "BAD_REQUEST", message: "تم تسليم هذه المحاولة مسبقًا" });
      const examRows = await database.select().from(exams).where(eq(exams.id, attempt.examId)).limit(1);
      const deadline = new Date(attempt.startedAt).getTime() + (examRows[0]?.durationMinutes ?? 0) * 60 * 1000;
      if (Date.now() > deadline + 5000) throw new TRPCError({ code: "BAD_REQUEST", message: "انتهى وقت الامتحان" });
      const questionRows = await database.select().from(questions).where(eq(questions.examId, attempt.examId));
      const answerMap = new Map(input.answers.map(item => [item.questionId, item.answer ?? ""]));
      for (const question of questionRows) {
        const answerText = answerMap.get(question.id) ?? "";
        const objective = question.type !== "essay" && question.correctAnswer !== null;
        const isCorrect = objective ? answerText === question.correctAnswer : null;
        const pointsAwarded = isCorrect ? question.points : 0;
        await database.insert(answers).values({ attemptId: attempt.id, questionId: question.id, answer: answerText, isCorrect, pointsAwarded });
      }
      await database.update(attempts).set({ status: "submitted", submittedAt: new Date() }).where(eq(attempts.id, attempt.id));
      const totals = await dbLib.recalculateAttempt(attempt.id);
      return { ...totals, attemptId: attempt.id, examId: attempt.examId };
    }),
    detail: protectedProcedure.input(z.object({ attemptId: z.number().int().positive() })).query(async ({ ctx, input }) => {
      const database = await getDatabase();
      const rows = await database.select({ attempt: attempts, exam: exams }).from(attempts).innerJoin(exams, eq(attempts.examId, exams.id)).where(and(eq(attempts.id, input.attemptId), eq(attempts.userId, ctx.user.id))).limit(1);
      if (rows.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "النتيجة غير موجودة" });
      const questionRows = await database.select().from(questions).where(eq(questions.examId, rows[0].attempt.examId)).orderBy(questions.sortOrder, questions.id);
      const answerRows = await database.select().from(answers).where(eq(answers.attemptId, input.attemptId));
      return { ...rows[0], questions: questionRows.map(question => publicQuestion(question, rows[0].exam.showAnswers)), answers: answerRows };
    }),
  }),

  certificates: router({
    create: protectedProcedure.input(z.object({ attemptId: z.number().int().positive(), template: z.enum(["classic", "modern"]).default("classic") })).mutation(async ({ ctx, input }) => {
      const database = await getDatabase();
      const rows = await database.select({ attempt: attempts, exam: exams }).from(attempts).innerJoin(exams, eq(attempts.examId, exams.id)).where(and(eq(attempts.id, input.attemptId), eq(attempts.userId, ctx.user.id))).limit(1);
      if (rows.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "النتيجة غير موجودة" });
      if (rows[0].attempt.status === "in_progress") throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكن إصدار شهادة قبل تسليم الامتحان" });
      const quote = rows[0].attempt.percentage >= 85 ? "أداء متميز يستحق التقدير" : rows[0].attempt.percentage >= 70 ? "جهد طيب ونتيجة مشرفة" : "نقدّر اجتهادك ونشجعك على مواصلة التقدم";
      const existing = await database.select().from(certificates).where(and(eq(certificates.attemptId, input.attemptId), eq(certificates.template, input.template))).orderBy(desc(certificates.id)).limit(1);
      if (existing.length > 0) return { ...existing[0], studentName: ctx.user.name || "طالب طلاب البلينا", examTitle: rows[0].exam.title, score: rows[0].attempt.score, maxScore: rows[0].attempt.maxScore, percentage: rows[0].attempt.percentage };
      await database.insert(certificates).values({ attemptId: input.attemptId, userId: ctx.user.id, examId: rows[0].attempt.examId, template: input.template, quote });
      const created = await database.select().from(certificates).where(eq(certificates.attemptId, input.attemptId)).orderBy(desc(certificates.id)).limit(1);
      return { ...created[0], studentName: ctx.user.name || "طالب طلاب البلينا", examTitle: rows[0].exam.title, score: rows[0].attempt.score, maxScore: rows[0].attempt.maxScore, percentage: rows[0].attempt.percentage };
    }),
  }),

  admin: router({
    content: adminProcedure.query(async () => {
      const database = await getDatabase();
      const [sections, services, news, resources] = await Promise.all([
        database.select().from(contentSections).orderBy(asc(contentSections.displayOrder), asc(contentSections.id)),
        database.select().from(siteServices).orderBy(asc(siteServices.displayOrder), asc(siteServices.id)),
        database.select().from(announcements).orderBy(desc(announcements.createdAt)),
        database.select().from(learningResources).orderBy(desc(learningResources.createdAt)),
      ]);
      return { sections, services, announcements: news, resources };
    }),
    createSection: adminProcedure.input(sectionInput).mutation(async ({ input }) => { const database = await getDatabase(); await database.insert(contentSections).values(input); return { success: true }; }),
    updateSection: adminProcedure.input(z.object({ id: z.number().int().positive() }).merge(sectionInput)).mutation(async ({ input }) => { const database = await getDatabase(); const { id, ...changes } = input; await database.update(contentSections).set(changes).where(eq(contentSections.id, id)); return { success: true }; }),
    deleteSection: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => { const database = await getDatabase(); await database.delete(contentSections).where(eq(contentSections.id, input.id)); return { success: true }; }),
    createService: adminProcedure.input(serviceInput).mutation(async ({ input }) => { const database = await getDatabase(); await database.insert(siteServices).values(input); return { success: true }; }),
    updateService: adminProcedure.input(z.object({ id: z.number().int().positive() }).merge(serviceInput)).mutation(async ({ input }) => { const database = await getDatabase(); const { id, ...changes } = input; await database.update(siteServices).set(changes).where(eq(siteServices.id, id)); return { success: true }; }),
    deleteService: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => { const database = await getDatabase(); await database.delete(siteServices).where(eq(siteServices.id, input.id)); return { success: true }; }),
    createAnnouncement: adminProcedure.input(announcementInput).mutation(async ({ input }) => { const database = await getDatabase(); await database.insert(announcements).values(input); return { success: true }; }),
    updateAnnouncement: adminProcedure.input(z.object({ id: z.number().int().positive() }).merge(announcementInput)).mutation(async ({ input }) => { const database = await getDatabase(); const { id, ...changes } = input; await database.update(announcements).set(changes).where(eq(announcements.id, id)); return { success: true }; }),
    deleteAnnouncement: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => { const database = await getDatabase(); await database.delete(announcements).where(eq(announcements.id, input.id)); return { success: true }; }),
    createResource: adminProcedure.input(resourceInput).mutation(async ({ input }) => { const database = await getDatabase(); await database.insert(learningResources).values(input); return { success: true }; }),
    updateResource: adminProcedure.input(z.object({ id: z.number().int().positive() }).merge(resourceInput)).mutation(async ({ input }) => { const database = await getDatabase(); const { id, ...changes } = input; await database.update(learningResources).set(changes).where(eq(learningResources.id, id)); return { success: true }; }),
    deleteResource: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => { const database = await getDatabase(); await database.delete(learningResources).where(eq(learningResources.id, input.id)); return { success: true }; }),
    stats: adminProcedure.query(async () => {
      const database = await getDatabase();
      const [examRows, userRows, attemptRows, certificateRows] = await Promise.all([
        database.select({ id: exams.id }).from(exams),
        database.select({ id: users.id }).from(users),
        database.select({ id: attempts.id }).from(attempts),
        database.select({ id: certificates.id }).from(certificates),
      ]);
      return { exams: examRows.length, students: userRows.length, attempts: attemptRows.length, certificates: certificateRows.length };
    }),
    exams: adminProcedure.query(async () => {
      const database = await getDatabase();
      const rows = await database.select().from(exams).orderBy(desc(exams.createdAt));
      const result = await Promise.all(rows.map(async exam => {
        const questionRows = await database.select({ id: questions.id }).from(questions).where(eq(questions.examId, exam.id));
        return { ...exam, questionCount: questionRows.length };
      }));
      return result;
    }),
    createExam: adminProcedure.input(examInput).mutation(async ({ input }) => {
      const database = await getDatabase();
      const slug = `${input.title.toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]+/g, "-").slice(0, 120)}-${Date.now()}`;
      await database.insert(exams).values({ ...input, slug });
      return { success: true };
    }),
    updateExam: adminProcedure.input(z.object({ id: z.number().int().positive() }).merge(examInput)).mutation(async ({ input }) => {
      const database = await getDatabase();
      const { id, ...changes } = input;
      await database.update(exams).set(changes).where(eq(exams.id, id));
      return { success: true };
    }),
    deleteExam: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
      const database = await getDatabase();
      const attemptRows = await database.select({ id: attempts.id }).from(attempts).where(eq(attempts.examId, input.id)).limit(1);
      if (attemptRows.length > 0) throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكن حذف امتحان له محاولات محفوظة" });
      await database.delete(questions).where(eq(questions.examId, input.id));
      await database.delete(exams).where(eq(exams.id, input.id));
      return { success: true };
    }),
    questions: adminProcedure.input(z.object({ examId: z.number().int().positive() })).query(async ({ input }) => {
      const database = await getDatabase();
      const rows = await database.select().from(questions).where(eq(questions.examId, input.examId)).orderBy(questions.sortOrder, questions.id);
      return rows.map(question => publicQuestion(question, true));
    }),
    createQuestion: adminProcedure.input(questionInput).mutation(async ({ input }) => {
      const database = await getDatabase();
      await database.insert(questions).values({ ...input, options: JSON.stringify(input.options) });
      return { success: true };
    }),
    updateQuestion: adminProcedure.input(z.object({ id: z.number().int().positive() }).merge(questionInput.omit({ examId: true }))).mutation(async ({ input }) => {
      const database = await getDatabase();
      const { id, options, ...changes } = input;
      await database.update(questions).set({ ...changes, options: JSON.stringify(options) }).where(eq(questions.id, id));
      return { success: true };
    }),
    deleteQuestion: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
      const database = await getDatabase();
      await database.delete(questions).where(eq(questions.id, input.id));
      return { success: true };
    }),
    archive: adminProcedure.input(z.object({ search: z.string().optional().default("") })).query(async ({ input }) => {
      const database = await getDatabase();
      const filters = input.search ? like(users.name, `%${input.search}%`) : undefined;
      const rows = await database.select({ attempt: attempts, user: users, exam: exams }).from(attempts).innerJoin(users, eq(attempts.userId, users.id)).innerJoin(exams, eq(attempts.examId, exams.id)).where(filters).orderBy(desc(attempts.createdAt));
      return rows.map(row => ({ ...row.attempt, studentName: row.user.name || "طالب بلا اسم", studentEmail: row.user.email || "", examTitle: row.exam.title, subject: row.exam.subject }));
    }),
    attemptDetail: adminProcedure.input(z.object({ attemptId: z.number().int().positive() })).query(async ({ input }) => {
      const database = await getDatabase();
      const rows = await database.select({ attempt: attempts, user: users, exam: exams }).from(attempts).innerJoin(users, eq(attempts.userId, users.id)).innerJoin(exams, eq(attempts.examId, exams.id)).where(eq(attempts.id, input.attemptId)).limit(1);
      if (rows.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "المحاولة غير موجودة" });
      const questionRows = await database.select().from(questions).where(eq(questions.examId, rows[0].attempt.examId)).orderBy(questions.sortOrder, questions.id);
      const answerRows = await database.select().from(answers).where(eq(answers.attemptId, input.attemptId));
      return { ...rows[0], questions: questionRows.map(question => publicQuestion(question, true)), answers: answerRows };
    }),
    gradeEssay: adminProcedure.input(z.object({ attemptId: z.number().int().positive(), answerId: z.number().int().positive(), pointsAwarded: z.number().int().min(0).max(100) })).mutation(async ({ input }) => {
      const database = await getDatabase();
      const answerRows = await database.select({ answer: answers, question: questions }).from(answers).innerJoin(questions, eq(answers.questionId, questions.id)).where(and(eq(answers.id, input.answerId), eq(answers.attemptId, input.attemptId))).limit(1);
      if (answerRows.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "الإجابة غير موجودة" });
      const points = Math.min(input.pointsAwarded, answerRows[0].question.points);
      await database.update(answers).set({ pointsAwarded: points, isCorrect: points >= answerRows[0].question.points }).where(eq(answers.id, input.answerId));
      await database.update(attempts).set({ status: "graded" }).where(eq(attempts.id, input.attemptId));
      return await dbLib.recalculateAttempt(input.attemptId);
    }),
    createCertificate: adminProcedure.input(z.object({ attemptId: z.number().int().positive(), template: z.enum(["classic", "modern"]).default("classic") })).mutation(async ({ input }) => {
      const database = await getDatabase();
      const rows = await database.select({ attempt: attempts, user: users, exam: exams }).from(attempts).innerJoin(users, eq(attempts.userId, users.id)).innerJoin(exams, eq(attempts.examId, exams.id)).where(eq(attempts.id, input.attemptId)).limit(1);
      if (rows.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "المحاولة غير موجودة" });
      if (rows[0].attempt.status === "in_progress") throw new TRPCError({ code: "BAD_REQUEST", message: "لا يمكن إصدار شهادة قبل تسليم الامتحان" });
      const quote = rows[0].attempt.percentage >= 85 ? "أداء متميز يستحق التقدير" : rows[0].attempt.percentage >= 70 ? "جهد طيب ونتيجة مشرفة" : "نقدّر اجتهادك ونشجعك على مواصلة التقدم";
      const existing = await database.select().from(certificates).where(and(eq(certificates.attemptId, input.attemptId), eq(certificates.template, input.template))).orderBy(desc(certificates.id)).limit(1);
      if (existing.length > 0) return { ...existing[0], studentName: rows[0].user.name || "طالب بلا اسم", examTitle: rows[0].exam.title, score: rows[0].attempt.score, maxScore: rows[0].attempt.maxScore, percentage: rows[0].attempt.percentage };
      await database.insert(certificates).values({ attemptId: input.attemptId, userId: rows[0].attempt.userId, examId: rows[0].attempt.examId, template: input.template, quote });
      const created = await database.select().from(certificates).where(and(eq(certificates.attemptId, input.attemptId), eq(certificates.template, input.template))).orderBy(desc(certificates.id)).limit(1);
      return { ...created[0], studentName: rows[0].user.name || "طالب بلا اسم", examTitle: rows[0].exam.title, score: rows[0].attempt.score, maxScore: rows[0].attempt.maxScore, percentage: rows[0].attempt.percentage };
    }),
    exportRows: adminProcedure.query(async () => {
      const database = await getDatabase();
      const rows = await database.select({ attempt: attempts, user: users, exam: exams }).from(attempts).innerJoin(users, eq(attempts.userId, users.id)).innerJoin(exams, eq(attempts.examId, exams.id)).orderBy(desc(attempts.createdAt));
      return rows.map(row => ({ studentName: row.user.name || "طالب بلا اسم", studentEmail: row.user.email || "", examTitle: row.exam.title, score: row.attempt.score, maxScore: row.attempt.maxScore, percentage: row.attempt.percentage, attemptNumber: row.attempt.attemptNumber, submittedAt: row.attempt.submittedAt?.toISOString() || "" }));
    }),
  }),
});

export type AppRouter = typeof appRouter;
