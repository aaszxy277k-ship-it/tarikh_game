import { AIChatBox, type Message } from "@/components/AIChatBox";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BookOpen, Lightbulb, Sparkles } from "lucide-react";
import { useState } from "react";

const welcomeMessage: Message = {
  role: "assistant",
  content:
    "أهلًا بك! أنا **رفيقك**، مساعدك التعليمي الذكي من طلاب البلينا.\n\nأقدر أشرح لك أي درس خطوة بخطوة، أحل معك سؤالًا، ألخص فصلًا، أو أجهز لك اختبارًا قصيرًا. اكتب سؤالك كما تحب، وسأشرح لك بطريقة تناسب مستواك.",
};

export default function AICompanion() {
  const [messages, setMessages] = useState<Message[]>([welcomeMessage]);
  const chat = trpc.ai.chat.useMutation({
    onSuccess: (data) => {
      setMessages((current) => [...current, { role: "assistant", content: data.answer }]);
    },
    onError: () => {
      setMessages((current) => [
        ...current,
        { role: "assistant", content: "حدث عطل مؤقت في رفيقك. حاول مرة أخرى بعد لحظات، وسأكمل معك الشرح." },
      ]);
    },
  });

  const sendMessage = (content: string) => {
    const nextMessages = [...messages, { role: "user" as const, content }];
    setMessages(nextMessages);
    chat.mutate({ messages: nextMessages.filter((message): message is Extract<Message, { role: "user" | "assistant" }> => message.role !== "system") });
  };

  return (
    <div className="page-shell companion-page">
      <div className="companion-hero">
        <div>
          <Badge className="companion-badge"><Sparkles size={14} /> رفيقك التعليمي الذكي</Badge>
          <h1>ذاكر مع رفيقك،<br /><em>وافهمها ببساطة.</em></h1>
          <p>شرح للدروس، حل للأسئلة، تلخيص للمناهج، وتدريب قبل الامتحان — في محادثة واحدة وباللغة العربية.</p>
        </div>
        <div className="companion-hero-mark"><Sparkles size={42} /><span>رفيقك</span><small>من طلاب البلينا لكل طالب</small></div>
      </div>
      <div className="companion-grid">
        <Card className="companion-chat-card">
          <CardContent className="companion-chat-content">
            <div className="companion-chat-heading"><div className="companion-avatar"><Sparkles size={19} /></div><div><strong>رفيقك | مساعدك التعليمي الذكي</strong><span>متاح لمساعدتك في أي مادة</span></div><span className="companion-online">متصل</span></div>
            <AIChatBox
              messages={messages}
              onSendMessage={sendMessage}
              isLoading={chat.isPending}
              height="620px"
              placeholder="اكتب سؤالك أو اسم الدرس هنا..."
              emptyStateMessage="ابدأ بسؤال رفيقك عن أي درس"
              suggestedPrompts={["اشرح لي مفهوم الدولة بطريقة سهلة", "لخص لي درسًا في 5 نقاط", "أنشئ لي اختبارًا قصيرًا في التاريخ"]}
            />
          </CardContent>
        </Card>
        <aside className="companion-side">
          <div className="companion-side-card"><BookOpen size={22} /><h3>اشرح لي أي درس</h3><p>اكتب اسم المادة والدرس، واطلب شرحًا مبسطًا أو شرحًا تفصيليًا حسب مستواك.</p></div>
          <div className="companion-side-card"><Lightbulb size={22} /><h3>اطلب طريقة الحل</h3><p>رفيقك لا يعطيك النتيجة فقط؛ بل يوضح خطوات التفكير والمراجعة حتى تفهم الإجابة.</p></div>
          <div className="companion-side-note"><strong>نصيحة للمذاكرة</strong><p>اطلب من رفيقك أن يسألك سؤالًا واحدًا في كل مرة، ثم حاول الإجابة قبل رؤية التوضيح.</p></div>
        </aside>
      </div>
    </div>
  );
}
