import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, BookOpen, BookOpenCheck, Bot, Calculator, CalendarDays, FileText, GraduationCap, Landmark, ListChecks, Medal, NotebookPen, School, Sparkles, TimerReset, TrendingUp, Trophy, Users } from "lucide-react";

const iconMap: Record<string, typeof BookOpen> = { BookOpen, BookOpenCheck, Bot, Calculator, CalendarDays, FileText, GraduationCap, Landmark, ListChecks, Medal, NotebookPen, School, Sparkles, TimerReset, TrendingUp, Trophy, Users };

function Icon({ name }: { name?: string | null }) {
  const Component = iconMap[name || "BookOpen"] || BookOpen;
  return <Component size={21} />;
}

export default function LearningHub() {
  const content = trpc.content.home.useQuery();
  if (content.isLoading) return <section className="learning-hub page-shell"><div className="loading-block">جارٍ تحميل الأقسام التعليمية...</div></section>;
  const data = content.data;
  if (!data) return null;
  return <>
    {data.announcements.length > 0 && <section className="announcement-strip"><div className="page-shell announcement-inner"><span className="announcement-label">إعلانات طلاب البلينا</span><div className="announcement-items">{data.announcements.slice(0, 3).map(item => <a key={item.id} href={item.link || "#"}>{item.title}<span>{item.body}</span></a>)}</div></div></section>}
    <section className="learning-hub page-shell"><div className="section-heading"><div><span className="eyebrow">مساحتك التعليمية</span><h2>تعلّم بالطريقة التي تناسبك</h2><p>أقسام منظمة للثانوية العامة والبكالوريا والصفوف المختلفة، وتُحدّث مباشرة من لوحة الإدارة.</p></div></div><div className="learning-section-grid">{data.sections.map(section => <Card key={section.id} className="learning-section-card"><CardContent><div className="hub-icon"><Icon name={section.icon} /></div><h3>{section.title}</h3><p>{section.description}</p><button type="button">استكشف القسم <ArrowLeft size={15} /></button></CardContent></Card>)}</div></section>
    <section className="services-band"><div className="page-shell"><div className="section-heading"><div><span className="eyebrow">خدمات للطالب</span><h2>أدوات تساعدك كل يوم</h2></div></div><div className="services-grid">{data.services.filter(service => service.title !== "مكتبة كليوباترا").map(service => <Card key={service.id} className="service-card"><CardContent><div className="service-icon"><Icon name={service.icon} /></div><div><h3>{service.title}</h3><p>{service.description}</p></div>{service.link && <a href={service.link} aria-label={service.title}><ArrowLeft size={16} /></a>}</CardContent></Card>)}</div></div></section>
    {data.services.filter(service => service.title === "مكتبة البلينا").map(library => <section id="blina-library" className="cleopatra-library page-shell" key={library.id}><div className="cleopatra-library-inner"><div className="cleopatra-library-icon"><Icon name={library.icon} /></div><div><span className="eyebrow">دليل المكتبات في البلينا</span><h2>{library.title}</h2><p>{library.description}</p><p className="cleopatra-library-note">قسم مكتبة البلينا على منصة طلاب البلينا يسهّل وصول الطلاب إلى معلومات المكتبة وخدماتها وموقعها داخل البلينا. ويمكن إضافة أسماء المكتبات الأخرى هنا تباعًا.</p></div><div className="cleopatra-library-tag">كتب<br />مراجع<br />أدوات تعليمية</div></div></section>)}
    <section className="resources-section page-shell"><div className="section-heading"><div><span className="eyebrow">آخر الإضافات</span><h2>مذكرات وموارد تعليمية</h2><p>يضيفها المدير ويصنّفها حسب الصف والنظام والمادة.</p></div></div>{data.resources.length ? <div className="resource-grid">{data.resources.map(resource => <Card key={resource.id} className="resource-card"><CardContent><div className="resource-top"><Badge variant="outline">{resource.kind}</Badge><span>{resource.subject || "محتوى تعليمي"}</span></div><h3>{resource.title}</h3><p>{resource.description || "مورد تعليمي جديد لطلاب البلينا."}</p><small>{[resource.system, resource.grade].filter(Boolean).join(" · ") || "متاح لجميع الطلاب"}</small>{resource.url && <a href={resource.url} target="_blank" rel="noreferrer">فتح المورد <ArrowLeft size={14} /></a>}</CardContent></Card>)}</div> : <div className="empty-state"><div className="empty-icon"><NotebookPen size={25} /></div><h3>الموارد قيد الإعداد</h3><p>ستظهر المذكرات والمراجعات هنا فور إضافتها من لوحة المدير.</p></div>}</section>
  </>;
}
