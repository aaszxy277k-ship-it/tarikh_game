import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import AdminContentManager from "@/components/AdminContentManager";
import LearningHub from "@/components/LearningHub";
import AICompanion from "@/components/AICompanion";
import { trpc } from "@/lib/trpc";
import {
  Archive,
  ArrowLeft,
  Award,
  BarChart3,
  BookOpenCheck,
  Check,
  CheckCircle2,
  Clock3,
  Download,
  FileSpreadsheet,
  GraduationCap,
  LayoutDashboard,
  LogIn,
  LogOut,
  Menu,
  PenLine,
  Play,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  TimerReset,
  Trophy,
  Users,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

type View = "home" | "exams" | "results" | "archive" | "admin" | "exam" | "assistant";
type ExamDraft = {
  title: string;
  subject: string;
  grade: string;
  description: string;
  durationMinutes: number;
  maxAttempts: number;
  isPublished: boolean;
  shuffleQuestions: boolean;
  showAnswers: boolean;
};
type QuestionDraft = {
  type: "mcq" | "true_false" | "essay";
  prompt: string;
  options: string[];
  correctAnswer: string;
  points: number;
  sortOrder: number;
};

const blankExam: ExamDraft = {
  title: "",
  subject: "",
  grade: "",
  description: "",
  durationMinutes: 30,
  maxAttempts: 1,
  isPublished: false,
  shuffleQuestions: false,
  showAnswers: true,
};

const blankQuestion: QuestionDraft = {
  type: "mcq",
  prompt: "",
  options: ["", "", "", ""],
  correctAnswer: "",
  points: 1,
  sortOrder: 0,
};

function formatDate(value: string | Date | null | undefined) {
  if (!value) return "غير محدد";
  return new Intl.DateTimeFormat("ar-EG", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}

function formatShortDate(value: string | Date | null | undefined) {
  if (!value) return "غير محدد";
  return new Intl.DateTimeFormat("ar-EG", { dateStyle: "medium" }).format(new Date(value));
}

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand-lockup ${compact ? "brand-lockup-compact" : ""}`}>
      <div className="brand-mark" aria-hidden="true"><svg viewBox="0 0 48 48" role="presentation"><g fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"><path d="M24 8c5 0 8 3 8 8v5c0 3 2 5 5 5"/><path d="M40 24c0 5-3 8-8 8h-5c-3 0-5 2-5 5"/><path d="M24 40c-5 0-8-3-8-8v-5c0-3-2-5-5-5"/><path d="M8 24c0-5 3-8 8-8h5c3 0 5-2 5-5"/><path d="M15 11c-4 2-5 6-3 10l2 4c1 3 0 5-3 7"/><path d="M33 11c4 2 5 6 3 10l-2 4c-1 3 0 5 3 7"/></g><circle cx="24" cy="24" r="2.5" fill="#4c8a9e"/></svg></div>
      <div>
        <strong>طلاب البلينا</strong>
        {!compact && <small>منصة الامتحانات الإلكترونية</small>}
      </div>
    </div>
  );
}

function SectionHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="section-heading">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
        {description && <p>{description}</p>}
      </div>
      {action}
    </div>
  );
}

function StatCard({ icon: Icon, value, label, tone }: { icon: typeof Users; value: string | number; label: string; tone: string }) {
  return (
    <div className={`stat-card ${tone}`}>
      <div className="stat-icon"><Icon size={20} /></div>
      <div><strong>{value}</strong><span>{label}</span></div>
    </div>
  );
}

function StatusPill({ published }: { published: boolean }) {
  return <Badge variant={published ? "default" : "outline"} className={published ? "pill-success" : "pill-muted"}>{published ? "منشور" : "مسودة"}</Badge>;
}

function ExamCard({ exam, onStart, isLoggedIn }: { exam: any; onStart: (id: number) => void; isLoggedIn: boolean }) {
  return (
    <Card className="exam-card">
      <CardContent className="p-0">
        <div className="exam-card-top"><Badge variant="outline">{exam.subject}</Badge><span>{exam.grade}</span></div>
        <h3>{exam.title}</h3>
        <p>{exam.description || "اختبر فهمك مع أسئلة منظمة ونتيجة محفوظة في أرشيفك."}</p>
        <div className="exam-meta"><span><Clock3 size={16} /> {exam.durationMinutes} دقيقة</span><span><BookOpenCheck size={16} /> {exam.questionCount} سؤال</span><span><RefreshCw size={16} /> {exam.maxAttempts} محاولات</span></div>
        <Button className="w-full" onClick={() => onStart(exam.id)}><Play size={16} /> {isLoggedIn ? "ابدأ الامتحان" : "سجّل الدخول للبدء"}</Button>
      </CardContent>
    </Card>
  );
}

function EmptyState({ icon: Icon, title, description, action }: { icon: typeof Archive; title: string; description: string; action?: React.ReactNode }) {
  return <div className="empty-state"><div className="empty-icon"><Icon size={26} /></div><h3>{title}</h3><p>{description}</p>{action}</div>;
}

function PhoneLoginDialog({ open, onClose, onSuccess }: { open: boolean; onClose: () => void; onSuccess: () => void }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");
  const register = trpc.auth.register.useMutation({ onSuccess: () => { setName(""); setPhone(""); setError(""); onSuccess(); }, onError: errorValue => setError(errorValue.message) });
  if (!open) return null;
  const submit = (event: React.FormEvent) => { event.preventDefault(); setError(""); register.mutate({ name, phone }); };
  return <div className="auth-overlay" role="dialog" aria-modal="true" aria-labelledby="phone-login-title"><div className="auth-dialog"><button className="auth-close" onClick={onClose} aria-label="إغلاق"><X size={18} /></button><div className="exam-intro-art auth-art"><Users size={34} /></div><span className="eyebrow">دخول الطلاب</span><h2 id="phone-login-title">سجّل باسمك ورقم هاتفك</h2><p>لا نستخدم البريد الإلكتروني. اكتب بياناتك مرة واحدة للوصول إلى الامتحانات وحفظ نتائجك.</p><form onSubmit={submit} className="form-stack"><Field label="الاسم بالكامل"><Input value={name} onChange={event => setName(event.target.value)} placeholder="مثال: أحمد محمد" autoFocus /></Field><Field label="رقم الهاتف"><Input value={phone} onChange={event => setPhone(event.target.value)} placeholder="01xxxxxxxxx" inputMode="tel" dir="ltr" /></Field>{error && <div className="error-box">{error}</div>}<Button type="submit" size="lg" disabled={register.isPending}>{register.isPending ? "جارٍ تسجيل الدخول..." : "دخول / تسجيل جديد"}</Button></form><small className="auth-note">سيتم حفظ الاسم ورقم الهاتف مع نتائج الامتحانات فقط.</small></div></div>;
}

function ExamRunner({ examId, onFinish, onBack }: { examId: number; onFinish: (attemptId: number) => void; onBack: () => void }) {
  const [session, setSession] = useState<any>(null);
  const [answersByQuestion, setAnswersByQuestion] = useState<Record<string, string>>({});
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [error, setError] = useState("");
  const submittingRef = useRef(false);
  const startMutation = trpc.attempts.start.useMutation({ onError: errorValue => setError(errorValue.message) });
  const submitMutation = trpc.attempts.submit.useMutation({
    onSuccess: result => onFinish(result.attemptId),
    onError: errorValue => { setError(errorValue.message); submittingRef.current = false; },
  });

  const begin = async () => {
    setError("");
    const result = await startMutation.mutateAsync({ examId });
    setSession(result);
    setSecondsLeft(result.exam.durationMinutes * 60);
  };

  const submit = () => {
    if (!session || submittingRef.current) return;
    submittingRef.current = true;
    submitMutation.mutate({
      attemptId: session.attempt.id,
      answers: session.questions.map((question: any) => ({ questionId: question.id, answer: answersByQuestion[String(question.id)] || "" })),
    });
  };

  useEffect(() => {
    if (!session || submitMutation.isSuccess) return;
    const startedAt = new Date(session.attempt.startedAt).getTime();
    const endAt = startedAt + session.exam.durationMinutes * 60 * 1000;
    const tick = () => {
      const remaining = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
      setSecondsLeft(remaining);
      if (remaining === 0) submit();
    };
    tick();
    const timer = window.setInterval(tick, 1000);
    return () => window.clearInterval(timer);
  }, [session, submitMutation.isSuccess, answersByQuestion]);

  if (!session) {
    return <div className="page-shell narrow-shell"><button className="back-link" onClick={onBack}><ArrowLeft size={16} /> العودة للامتحانات</button><Card className="exam-intro-card"><div className="exam-intro-art"><TimerReset size={42} /></div><Badge variant="outline">جاهز للبدء</Badge><h1>ابدأ امتحانك بثقة</h1><p>سيبدأ العداد بمجرد الضغط على زر البدء. تُحفظ إجاباتك عند التسليم وتظهر نتيجتك في أرشيف النتائج.</p><div className="intro-rules"><span><Clock3 size={17} /> {startMutation.data?.exam.durationMinutes || "—"} دقيقة</span><span><BookOpenCheck size={17} /> أسئلة متنوعة</span><span><ShieldCheck size={17} /> حفظ آمن للنتيجة</span></div>{error && <div className="error-box">{error}</div>}<Button size="lg" onClick={begin} disabled={startMutation.isPending}><Play size={18} /> {startMutation.isPending ? "يتم تجهيز الامتحان..." : "ابدأ الآن"}</Button></Card></div>;
  }

  const minutes = Math.floor(secondsLeft / 60).toString().padStart(2, "0");
  const seconds = (secondsLeft % 60).toString().padStart(2, "0");
  const progress = Math.round((Object.keys(answersByQuestion).filter(key => answersByQuestion[key]).length / Math.max(session.questions.length, 1)) * 100);

  return <div className="page-shell exam-shell"><div className="exam-runner-header"><div><button className="back-link" onClick={onBack}><ArrowLeft size={16} /> خروج بدون تسليم</button><h1>{session.exam.title}</h1><p>{session.exam.subject} · {session.exam.grade}</p></div><div className={`timer-box ${secondsLeft < 120 ? "timer-danger" : ""}`}><span>الوقت المتبقي</span><strong>{minutes}:{seconds}</strong></div></div><div className="exam-progress"><span>أنجزت {progress}% من الامتحان</span><div><i style={{ width: `${progress}%` }} /></div></div><div className="question-list">{session.questions.map((question: any, index: number) => <Card className="question-card" key={question.id}><CardContent><div className="question-number"><span>السؤال {index + 1}</span><Badge variant="outline">{question.type === "essay" ? "مقالي" : question.type === "true_false" ? "صح أم خطأ" : "اختيار من متعدد"}</Badge></div><h2>{question.prompt}</h2>{question.type === "essay" ? <textarea className="answer-textarea" rows={5} placeholder="اكتب إجابتك هنا..." value={answersByQuestion[String(question.id)] || ""} onChange={event => setAnswersByQuestion(current => ({ ...current, [String(question.id)]: event.target.value }))} /> : <div className="choice-list">{(question.options.length ? question.options : ["صحيح", "خطأ"]).map((option: string, optionIndex: number) => <label className={`choice-item ${answersByQuestion[String(question.id)] === option ? "choice-selected" : ""}`} key={option}><input type="radio" name={`question-${question.id}`} checked={answersByQuestion[String(question.id)] === option} onChange={() => setAnswersByQuestion(current => ({ ...current, [String(question.id)]: option }))} /><span className="choice-letter">{String.fromCharCode(1571 + optionIndex)}</span><span>{option}</span></label>)}</div>}</CardContent></Card>)}</div>{error && <div className="error-box">{error}</div>}<div className="submit-bar"><span>تأكد من مراجعة كل الإجابات قبل التسليم.</span><Button size="lg" onClick={() => { if (window.confirm("هل تريد تسليم الامتحان الآن؟")) submit(); }} disabled={submitMutation.isPending}><CheckCircle2 size={18} /> {submitMutation.isPending ? "جارٍ التصحيح..." : "تسليم الامتحان"}</Button></div></div>;
}

function ResultDetail({ attemptId, onBack }: { attemptId: number; onBack: () => void }) {
  const detail = trpc.attempts.detail.useQuery({ attemptId });
  const certificateMutation = trpc.certificates.create.useMutation();
  const [certificate, setCertificate] = useState<any>(null);
  if (detail.isLoading) return <LoadingBlock />;
  if (detail.isError || !detail.data) return <ErrorBlock message="تعذر تحميل تفاصيل النتيجة" onRetry={() => detail.refetch()} />;
  const data = detail.data;
  const answersMap = new Map(data.answers.map((answer: any) => [answer.questionId, answer]));
  return <div className="page-shell narrow-shell"><button className="back-link" onClick={onBack}><ArrowLeft size={16} /> العودة للنتائج</button><div className="result-hero"><div><span className="eyebrow">نتيجة محفوظة</span><h1>{data.exam.title}</h1><p>{formatDate(data.attempt.submittedAt)} · المحاولة رقم {data.attempt.attemptNumber}</p></div><div className="score-ring"><strong>{data.attempt.percentage}%</strong><span>{data.attempt.score} / {data.attempt.maxScore}</span></div></div><div className="result-actions"><Button onClick={async () => setCertificate(await certificateMutation.mutateAsync({ attemptId, template: "classic" }))} disabled={certificateMutation.isPending}><Award size={17} /> {certificateMutation.isPending ? "جارٍ إنشاء الشهادة..." : "إنشاء شهادة تقدير"}</Button><span className="muted-note">يمكنك طباعة الشهادة أو تنزيلها كصورة PNG.</span></div>{certificate && <CertificateCard certificate={certificate} />}{data.exam.showAnswers && <Card className="review-card"><CardHeader><CardTitle>مراجعة الإجابات</CardTitle></CardHeader><CardContent><div className="review-list">{data.questions.map((question: any, index: number) => { const answer: any = answersMap.get(question.id); const isEssay = question.type === "essay"; return <div className="review-item" key={question.id}><div className="review-title"><span>السؤال {index + 1}</span>{isEssay ? <Badge variant="outline">بانتظار مراجعة المقال</Badge> : answer?.isCorrect ? <Badge className="pill-success"><Check size={13} /> صحيح</Badge> : <Badge variant="outline" className="pill-danger"><X size={13} /> يحتاج مراجعة</Badge>}</div><p>{question.prompt}</p><div className="review-answer"><span>إجابتك:</span> {answer?.answer || "لم تتم الإجابة"}</div>{!isEssay && question.correctAnswer && <div className="review-correct"><span>الإجابة النموذجية:</span> {question.correctAnswer}</div>}</div>; })}</div></CardContent></Card>}</div>;
}

function CertificateCard({ certificate }: { certificate: any }) {
  const svgMarkup = useMemo(() => makeCertificateSvg(certificate), [certificate]);
  const downloadPng = async () => {
    const image = new Image();
    image.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = 1600; canvas.height = 1100;
      const context = canvas.getContext("2d");
      if (!context) return;
      context.fillStyle = "#fffdf8"; context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0);
      const link = document.createElement("a");
      link.download = "شهادة-طلاب-البلينا.png";
      link.href = canvas.toDataURL("image/png");
      link.click();
    };
    image.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgMarkup)}`;
  };
  return <Card className={`certificate-card certificate-${certificate.template}`}><div className="certificate-preview" dangerouslySetInnerHTML={{ __html: svgMarkup }} /><div className="certificate-actions"><Button variant="outline" onClick={downloadPng}><Download size={16} /> تنزيل PNG</Button><Button variant="secondary" onClick={() => window.print()}><Award size={16} /> طباعة / PDF</Button></div></Card>;
}

function makeCertificateSvg(certificate: any) {
  const safe = (value: string) => value.replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[character] || character));
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1100" viewBox="0 0 1600 1100"><rect width="1600" height="1100" fill="#fffdf8"/><rect x="38" y="38" width="1524" height="1024" rx="24" fill="none" stroke="#143b5d" stroke-width="8"/><rect x="62" y="62" width="1476" height="976" rx="18" fill="none" stroke="#d4a34f" stroke-width="2"/><circle cx="800" cy="175" r="58" fill="#143b5d"/><text x="800" y="166" text-anchor="middle" fill="#f8e4b4" font-size="30" font-family="Arial" font-weight="700">ط ب</text><text x="800" y="205" text-anchor="middle" fill="#fff" font-size="22" font-family="Arial">طلاب</text><text x="800" y="310" text-anchor="middle" fill="#143b5d" font-size="54" font-family="Arial" font-weight="700">شهادة تقدير</text><text x="800" y="390" text-anchor="middle" fill="#7b6b58" font-size="26" font-family="Arial">تُمنح إلى الطالب / ة</text><text x="800" y="500" text-anchor="middle" fill="#143b5d" font-size="60" font-family="Arial" font-weight="700">${safe(certificate.studentName)}</text><line x1="420" y1="530" x2="1180" y2="530" stroke="#d4a34f" stroke-width="3"/><text x="800" y="620" text-anchor="middle" fill="#4a5862" font-size="28" font-family="Arial">تقديراً لأدائه في امتحان</text><text x="800" y="680" text-anchor="middle" fill="#143b5d" font-size="36" font-family="Arial" font-weight="700">${safe(certificate.examTitle)}</text><text x="800" y="760" text-anchor="middle" fill="#4a5862" font-size="28" font-family="Arial">الدرجة: ${certificate.score} من ${certificate.maxScore} · النسبة: ${certificate.percentage}%</text><text x="800" y="830" text-anchor="middle" fill="#143b5d" font-size="30" font-family="Arial">${safe(certificate.quote)}</text><text x="260" y="940" fill="#7b6b58" font-size="24" font-family="Arial">${safe(formatShortDate(certificate.issuedAt))}</text><text x="1340" y="940" text-anchor="end" fill="#143b5d" font-size="24" font-family="Arial" font-weight="700">إدارة طلاب البلينا</text></svg>`;
}

function ExamsView({ exams, isLoggedIn, onStart }: { exams: any[]; isLoggedIn: boolean; onStart: (id: number) => void }) {
  return <div className="page-shell"><SectionHeading eyebrow="الاختبارات المتاحة" title="الامتحانات المنشورة" description="كل امتحان هنا أعدّه المدير ليكون واضح الزمن والدرجة وعدد المحاولات." />{exams.length ? <div className="exam-grid">{exams.map(exam => <ExamCard key={exam.id} exam={exam} onStart={onStart} isLoggedIn={isLoggedIn} />)}</div> : <EmptyState icon={BookOpenCheck} title="لا توجد امتحانات منشورة بعد" description="سيظهر امتحان التاريخ للصف الثاني الثانوي هنا فور اكتمال مراجعة الإجابات النموذجية ونشره من لوحة المدير." />}</div>;
}

function ResultsView({ onOpenAttempt }: { onOpenAttempt: (id: number) => void }) {
  const dashboard = trpc.student.dashboard.useQuery();
  if (dashboard.isLoading) return <LoadingBlock />;
  const rows = dashboard.data || [];
  return <div className="page-shell"><SectionHeading eyebrow="مساحتك التعليمية" title="نتائجي" description="كل محاولاتك محفوظة هنا لتراجع تقدمك وتصدر شهادة تقدير عند الحاجة." />{rows.length === 0 ? <EmptyState icon={BarChart3} title="لا توجد نتائج بعد" description="ابدأ امتحانًا منشورًا وستظهر نتيجتك هنا تلقائيًا." /> : <div className="results-table-wrap"><table className="data-table"><thead><tr><th>الامتحان</th><th>المادة</th><th>الدرجة</th><th>النسبة</th><th>الحالة</th><th /></tr></thead><tbody>{rows.map((row: any) => <tr key={row.id}><td><strong>{row.examTitle}</strong><small>{formatShortDate(row.submittedAt)}</small></td><td>{row.subject}</td><td>{row.score} / {row.maxScore}</td><td><strong className="score-text">{row.percentage}%</strong></td><td><Badge variant="outline">{row.status === "graded" ? "مراجعة مكتملة" : row.status === "submitted" ? "تم التسليم" : "قيد التنفيذ"}</Badge></td><td><Button variant="ghost" size="sm" onClick={() => onOpenAttempt(row.id)}>عرض التفاصيل <ArrowLeft size={15} /></Button></td></tr>)}</tbody></table></div>}</div>;
}

function AdminAttemptDetail({ attemptId, onClose }: { attemptId: number; onClose: () => void }) {
  const detail = trpc.admin.attemptDetail.useQuery({ attemptId });
  const gradeEssay = trpc.admin.gradeEssay.useMutation({ onSuccess: () => detail.refetch() });
  const createCertificate = trpc.admin.createCertificate.useMutation();
  const [certificate, setCertificate] = useState<any>(null);
  const [template, setTemplate] = useState<"classic" | "modern">("classic");
  if (detail.isLoading) return <LoadingBlock />;
  if (detail.isError || !detail.data) return <ErrorBlock message="تعذر تحميل تفاصيل المحاولة" onRetry={() => detail.refetch()} />;
  const data = detail.data;
  const answersMap = new Map(data.answers.map((answer: any) => [answer.questionId, answer]));
  return <Card className="admin-attempt-detail"><CardHeader><div className="detail-header"><div><CardTitle>مراجعة محاولة الطالب</CardTitle><p>{data.user.name || "طالب بلا اسم"} · {data.exam.title}</p></div><Button variant="ghost" onClick={onClose}><X size={17} /></Button></div></CardHeader><CardContent><div className="detail-score"><span>النتيجة الحالية</span><strong>{data.attempt.score} / {data.attempt.maxScore} ({data.attempt.percentage}%)</strong></div><div className="review-list admin-review-list">{data.questions.map((question: any, index: number) => { const answer: any = answersMap.get(question.id); return <div className="review-item" key={question.id}><div className="review-title"><span>السؤال {index + 1}</span><Badge variant="outline">{question.type === "essay" ? "مقالي" : "موضوعي"}</Badge></div><p>{question.prompt}</p><div className="review-answer"><span>إجابة الطالب:</span> {answer?.answer || "لم تتم الإجابة"}</div>{question.type === "essay" && answer && <div className="grade-row"><label>درجة المقال من {question.points}</label><Input type="number" min={0} max={question.points} defaultValue={answer.pointsAwarded || 0} onBlur={event => gradeEssay.mutate({ attemptId, answerId: answer.id, pointsAwarded: Number(event.target.value) })} /><span>يُحفظ عند مغادرة الحقل</span></div>}{question.type !== "essay" && question.correctAnswer && <div className="review-correct"><span>الإجابة النموذجية:</span> {question.correctAnswer}</div>}</div>; })}</div><div className="certificate-admin-actions"><select className="form-select" value={template} onChange={event => setTemplate(event.target.value as "classic" | "modern")}><option value="classic">قالب كلاسيكي</option><option value="modern">قالب حديث</option></select><Button onClick={async () => setCertificate(await createCertificate.mutateAsync({ attemptId, template }))} disabled={createCertificate.isPending}><Award size={16} /> إصدار شهادة للطالب</Button></div>{certificate && <CertificateCard certificate={certificate} />}</CardContent></Card>;
}

function AdminView() {
  const [tab, setTab] = useState<"overview" | "exams" | "archive" | "content">("overview");
  const [examDraft, setExamDraft] = useState<ExamDraft>(blankExam);
  const [editingExamId, setEditingExamId] = useState<number | null>(null);
  const [selectedExamId, setSelectedExamId] = useState<number | null>(null);
  const [selectedAttemptId, setSelectedAttemptId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const stats = trpc.admin.stats.useQuery();
  const exams = trpc.admin.exams.useQuery();
  const archive = trpc.admin.archive.useQuery({ search });
  const exportRows = trpc.admin.exportRows.useQuery(undefined, { enabled: false });
  const createExam = trpc.admin.createExam.useMutation({ onSuccess: () => { exams.refetch(); setExamDraft(blankExam); } });
  const updateExam = trpc.admin.updateExam.useMutation({ onSuccess: () => { exams.refetch(); setEditingExamId(null); setExamDraft(blankExam); } });
  const deleteExam = trpc.admin.deleteExam.useMutation({ onSuccess: () => exams.refetch(), onError: error => window.alert(error.message) });

  const saveExam = (event: React.FormEvent) => {
    event.preventDefault();
    if (!examDraft.title || !examDraft.subject || !examDraft.grade) return;
    if (editingExamId) updateExam.mutate({ id: editingExamId, ...examDraft });
    else createExam.mutate(examDraft);
  };
  const editExam = (exam: any) => { setEditingExamId(exam.id); setExamDraft({ title: exam.title, subject: exam.subject, grade: exam.grade, description: exam.description || "", durationMinutes: exam.durationMinutes, maxAttempts: exam.maxAttempts, isPublished: exam.isPublished, shuffleQuestions: exam.shuffleQuestions, showAnswers: exam.showAnswers }); setTab("exams"); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const exportExcel = async () => {
    const result = await exportRows.refetch();
    if (!result.data) return;
    const header = ["اسم الطالب", "البريد الإلكتروني", "الامتحان", "الدرجة", "من", "النسبة", "المحاولة", "تاريخ التسليم"];
    const lines = result.data.map((row: any) => [row.studentName, row.studentEmail, row.examTitle, row.score, row.maxScore, `${row.percentage}%`, row.attemptNumber, row.submittedAt].map(value => `"${String(value).replace(/"/g, '""')}"`).join(","));
    const blob = new Blob(["\ufeff" + [header.join(","), ...lines].join("\n")], { type: "text/csv;charset=utf-8" });
    const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = "أرشيف-طلاب-البلينا.csv"; link.click(); URL.revokeObjectURL(link.href);
  };

  return <div className="page-shell admin-shell"><SectionHeading eyebrow="إدارة المنصة" title="لوحة تحكم المدير" description="من هنا تدير الامتحانات والأسئلة والأرشيف والشهادات وصحافة المحتوى بصلاحيات آمنة." action={<Button variant="outline" onClick={exportExcel}><FileSpreadsheet size={16} /> تصدير النتائج إلى Excel</Button>} /><div className="admin-tabs"><button className={tab === "overview" ? "active" : ""} onClick={() => setTab("overview")}><LayoutDashboard size={16} /> نظرة عامة</button><button className={tab === "content" ? "active" : ""} onClick={() => setTab("content")}><PenLine size={16} /> إدارة المحتوى</button><button className={tab === "exams" ? "active" : ""} onClick={() => setTab("exams")}><BookOpenCheck size={16} /> إدارة الامتحانات</button><button className={tab === "archive" ? "active" : ""} onClick={() => setTab("archive")}><Archive size={16} /> أرشيف المعلم</button></div>{tab === "content" && <AdminContentManager />}{tab === "overview" && <><div className="stats-grid"><StatCard icon={BookOpenCheck} value={stats.data?.exams ?? "—"} label="امتحان" tone="blue" /><StatCard icon={Users} value={stats.data?.students ?? "—"} label="طالب مسجل" tone="teal" /><StatCard icon={BarChart3} value={stats.data?.attempts ?? "—"} label="محاولة" tone="gold" /><StatCard icon={Award} value={stats.data?.certificates ?? "—"} label="شهادة" tone="purple" /></div><Card className="admin-callout"><CardContent><div className="callout-icon"><Sparkles size={22} /></div><div><h3>إدارة التعليم من مكان واحد</h3><p>أضف أقسامًا وخدمات وإعلانات وموارد من تبويب إدارة المحتوى، أو تابع الامتحانات والنتائج من التبويبات الحالية.</p></div><Button onClick={() => setTab("content")}>إدارة المحتوى <ArrowLeft size={16} /></Button></CardContent></Card></>}{tab === "exams" && <div className="admin-grid"><div><Card className="form-card"><CardHeader><CardTitle>{editingExamId ? "تعديل الامتحان" : "إضافة امتحان جديد"}</CardTitle></CardHeader><CardContent><form onSubmit={saveExam} className="form-stack"><Field label="اسم الامتحان"><Input value={examDraft.title} onChange={event => setExamDraft({ ...examDraft, title: event.target.value })} placeholder="مثال: مراجعة الوحدة الأولى" /></Field><div className="two-fields"><Field label="المادة"><Input value={examDraft.subject} onChange={event => setExamDraft({ ...examDraft, subject: event.target.value })} placeholder="التاريخ" /></Field><Field label="الصف"><Input value={examDraft.grade} onChange={event => setExamDraft({ ...examDraft, grade: event.target.value })} placeholder="الثاني الثانوي" /></Field></div><Field label="الوصف"><textarea className="form-textarea" rows={3} value={examDraft.description} onChange={event => setExamDraft({ ...examDraft, description: event.target.value })} /></Field><div className="two-fields"><Field label="الزمن بالدقائق"><Input type="number" min={1} value={examDraft.durationMinutes} onChange={event => setExamDraft({ ...examDraft, durationMinutes: Number(event.target.value) })} /></Field><Field label="عدد المحاولات"><Input type="number" min={1} value={examDraft.maxAttempts} onChange={event => setExamDraft({ ...examDraft, maxAttempts: Number(event.target.value) })} /></Field></div><div className="check-stack"><label><input type="checkbox" checked={examDraft.isPublished} onChange={event => setExamDraft({ ...examDraft, isPublished: event.target.checked })} /> نشر الامتحان للطلاب</label><label><input type="checkbox" checked={examDraft.shuffleQuestions} onChange={event => setExamDraft({ ...examDraft, shuffleQuestions: event.target.checked })} /> ترتيب الأسئلة عشوائيًا</label><label><input type="checkbox" checked={examDraft.showAnswers} onChange={event => setExamDraft({ ...examDraft, showAnswers: event.target.checked })} /> إظهار الإجابات بعد التسليم</label></div><div className="form-actions"><Button type="submit" disabled={createExam.isPending || updateExam.isPending}><Check size={16} /> حفظ الامتحان</Button>{editingExamId && <Button type="button" variant="ghost" onClick={() => { setEditingExamId(null); setExamDraft(blankExam); }}>إلغاء</Button>}</div></form></CardContent></Card>{selectedExamId && <QuestionManager examId={selectedExamId} />}</div><Card className="list-card"><CardHeader><CardTitle>كل الامتحانات</CardTitle></CardHeader><CardContent><div className="admin-exam-list">{(exams.data || []).map((exam: any) => <div className={`admin-exam-row ${selectedExamId === exam.id ? "selected" : ""}`} key={exam.id}><div className="row-main"><div className="row-icon"><BookOpenCheck size={18} /></div><div><strong>{exam.title}</strong><span>{exam.subject} · {exam.grade} · {exam.questionCount} سؤال</span></div></div><div className="row-actions"><StatusPill published={exam.isPublished} /><Button variant="ghost" size="icon-sm" title="تعديل" onClick={() => editExam(exam)}><PenLine size={16} /></Button><Button variant="ghost" size="icon-sm" title="إدارة الأسئلة" onClick={() => setSelectedExamId(exam.id)}><BookOpenCheck size={16} /></Button><Button variant="ghost" size="icon-sm" title="حذف" onClick={() => { if (window.confirm("حذف الامتحان؟")) deleteExam.mutate({ id: exam.id }); }}><X size={16} /></Button></div></div>)}{(!exams.data || exams.data.length === 0) && <EmptyState icon={BookOpenCheck} title="لا توجد امتحانات" description="أضف أول امتحان من النموذج." />}</div></CardContent></Card></div>}{tab === "archive" && <><Card className="archive-toolbar"><CardContent><div className="search-box"><Search size={18} /><Input value={search} onChange={event => setSearch(event.target.value)} placeholder="ابحث باسم الطالب..." /></div><span>يتم حفظ النتائج تلقائيًا في الأرشيف بعد التسليم.</span></CardContent></Card>{selectedAttemptId && <AdminAttemptDetail attemptId={selectedAttemptId} onClose={() => setSelectedAttemptId(null)} />}<div className="results-table-wrap"><table className="data-table"><thead><tr><th>الطالب</th><th>الامتحان</th><th>الدرجة</th><th>النسبة</th><th>المحاولة</th><th>التاريخ</th><th>إجراء</th></tr></thead><tbody>{(archive.data || []).map((row: any) => <tr key={row.id}><td><strong>{row.studentName}</strong><small>{row.studentEmail}</small></td><td>{row.examTitle}</td><td>{row.score} / {row.maxScore}</td><td><strong className="score-text">{row.percentage}%</strong></td><td>{row.attemptNumber}</td><td>{formatShortDate(row.submittedAt)}</td><td><Button variant="ghost" size="sm" onClick={() => setSelectedAttemptId(row.id)}>مراجعة <ArrowLeft size={14} /></Button></td></tr>)}</tbody></table>{(!archive.data || archive.data.length === 0) && <EmptyState icon={Archive} title="الأرشيف فارغ" description="ستظهر محاولات الطلاب هنا بعد أداء الامتحانات." />}</div></>}</div>;
}

function QuestionManager({ examId }: { examId: number }) {
  const [draft, setDraft] = useState<QuestionDraft>(blankQuestion);
  const [editingId, setEditingId] = useState<number | null>(null);
  const questions = trpc.admin.questions.useQuery({ examId });
  const create = trpc.admin.createQuestion.useMutation({ onSuccess: () => { questions.refetch(); setDraft({ ...blankQuestion, sortOrder: questions.data?.length || 0 }); } });
  const update = trpc.admin.updateQuestion.useMutation({ onSuccess: () => { questions.refetch(); setEditingId(null); setDraft(blankQuestion); } });
  const remove = trpc.admin.deleteQuestion.useMutation({ onSuccess: () => questions.refetch() });
  const setType = (type: QuestionDraft["type"]) => setDraft({ ...draft, type, options: type === "essay" ? [] : type === "true_false" ? ["صحيح", "خطأ"] : ["", "", "", ""] });
  const save = (event: React.FormEvent) => { event.preventDefault(); if (!draft.prompt) return; const payload = { ...draft, examId }; if (editingId) update.mutate({ id: editingId, ...payload }); else create.mutate(payload); };
  return <Card className="question-manager"><CardHeader><CardTitle>إدارة أسئلة الامتحان</CardTitle></CardHeader><CardContent><form onSubmit={save} className="form-stack"><Field label="نوع السؤال"><select className="form-select" value={draft.type} onChange={event => setType(event.target.value as QuestionDraft["type"])}><option value="mcq">اختيار من متعدد</option><option value="true_false">صح أو خطأ</option><option value="essay">مقالي</option></select></Field><Field label="نص السؤال"><textarea className="form-textarea" rows={3} value={draft.prompt} onChange={event => setDraft({ ...draft, prompt: event.target.value })} placeholder="اكتب السؤال بنفس الصياغة المطلوبة" /></Field>{draft.type !== "essay" && <div className="options-editor">{draft.options.map((option, index) => <div className="option-edit" key={index}><span>{String.fromCharCode(1571 + index)}</span><Input value={option} onChange={event => setDraft({ ...draft, options: draft.options.map((item, itemIndex) => itemIndex === index ? event.target.value : item) })} placeholder={`الاختيار ${index + 1}`} /></div>)}<Field label="الإجابة النموذجية (يحددها المدير فقط)"><select className="form-select" value={draft.correctAnswer} onChange={event => setDraft({ ...draft, correctAnswer: event.target.value })}><option value="">لم تُحدد بعد</option>{draft.options.filter(Boolean).map(option => <option key={option} value={option}>{option}</option>)}</select></Field></div>}{draft.type === "essay" && <p className="form-hint">لا توجد إجابة تلقائية لهذا السؤال؛ يراجع المدير الإجابة ويمنح الدرجة من الأرشيف.</p>}<div className="two-fields"><Field label="الدرجة"><Input type="number" min={0} value={draft.points} onChange={event => setDraft({ ...draft, points: Number(event.target.value) })} /></Field><Field label="الترتيب"><Input type="number" min={0} value={draft.sortOrder} onChange={event => setDraft({ ...draft, sortOrder: Number(event.target.value) })} /></Field></div><div className="form-actions"><Button type="submit"><Plus size={16} /> {editingId ? "حفظ التعديل" : "إضافة السؤال"}</Button>{editingId && <Button type="button" variant="ghost" onClick={() => { setEditingId(null); setDraft(blankQuestion); }}>إلغاء</Button>}</div></form><div className="question-admin-list">{(questions.data || []).map((question: any, index: number) => <div className="question-admin-row" key={question.id}><div><span className="question-index">{index + 1}</span><strong>{question.prompt}</strong><small>{question.type === "essay" ? "مقالي" : question.correctAnswer ? `الإجابة: ${question.correctAnswer}` : "الإجابة النموذجية لم تُحدد"} · {question.points} درجة</small></div><div><Button variant="ghost" size="icon-sm" onClick={() => { setEditingId(question.id); setDraft({ type: question.type, prompt: question.prompt, options: question.options, correctAnswer: question.correctAnswer || "", points: question.points, sortOrder: question.sortOrder }); }}><PenLine size={15} /></Button><Button variant="ghost" size="icon-sm" onClick={() => remove.mutate({ id: question.id })}><X size={15} /></Button></div></div>)}</div></CardContent></Card>;
}

function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label className="field"><span>{label}</span>{children}</label>; }
function LoadingBlock() { return <div className="loading-block"><RefreshCw className="spin" size={22} /> جارٍ تحميل البيانات...</div>; }
function ErrorBlock({ message, onRetry }: { message: string; onRetry: () => void }) { return <div className="error-state"><X size={24} /><p>{message}</p><Button variant="outline" onClick={onRetry}>حاول مرة أخرى</Button></div>; }

export default function Home() {
  const [view, setView] = useState<View>("home");
  const [selectedExamId, setSelectedExamId] = useState<number | null>(null);
  const [selectedAttemptId, setSelectedAttemptId] = useState<number | null>(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const me = trpc.auth.me.useQuery();
  const publicExams = trpc.exams.listPublic.useQuery();
  const logout = trpc.auth.logout.useMutation({ onSuccess: () => { me.refetch(); setView("home"); } });
  const isLoggedIn = Boolean(me.data);
  const isAdmin = me.data?.role === "admin";

  useEffect(() => { document.documentElement.lang = "ar"; document.documentElement.dir = "rtl"; document.title = "طلاب البلينا | منصة تعليمية مجانية"; }, []);

  const goToExam = (id: number) => { if (!isLoggedIn) { setAuthOpen(true); return; } setSelectedExamId(id); setView("exam"); setMobileMenu(false); };
  const nav = (nextView: View) => { setView(nextView); setMobileMenu(false); };

  let content: React.ReactNode;
  if (view === "exam" && selectedExamId) content = <ExamRunner examId={selectedExamId} onFinish={id => { setSelectedAttemptId(id); setView("results"); }} onBack={() => nav("exams")} />;
  else if (view === "exams") content = <ExamsView exams={publicExams.data || []} isLoggedIn={isLoggedIn} onStart={goToExam} />;
  else if (view === "results" && selectedAttemptId) content = <ResultDetail attemptId={selectedAttemptId} onBack={() => setSelectedAttemptId(null)} />;
  else if (view === "results") content = <ResultsView onOpenAttempt={id => setSelectedAttemptId(id)} />;
  else if (view === "assistant") content = <AICompanion />;
  else if (view === "admin" && isAdmin) content = <AdminView />;
  else if (view === "archive" && isAdmin) content = <AdminView />;
  else content = <HomeContent exams={publicExams.data || []} isLoggedIn={isLoggedIn} onStart={goToExam} onBrowse={() => nav("exams")} onLogin={() => setAuthOpen(true)} />;

  return <div className="app-root"><header className="site-header"><div className="header-inner"><button className="mobile-menu-button" onClick={() => setMobileMenu(current => !current)} aria-label="فتح القائمة"><Menu size={21} /></button><button className="brand-button" onClick={() => nav("home")}><BrandMark /></button><nav className={`main-nav ${mobileMenu ? "nav-open" : ""}`}><button className={view === "home" ? "active" : ""} onClick={() => nav("home")}>الرئيسية</button><button className={view === "exams" ? "active" : ""} onClick={() => nav("exams")}>الامتحانات</button><button className={view === "assistant" ? "active assistant-nav-link" : "assistant-nav-link"} onClick={() => nav("assistant")}><Sparkles size={14} /> رفيقك</button>{isLoggedIn && <button className={view === "results" ? "active" : ""} onClick={() => nav("results")}>نتائجي</button>}{isAdmin && <button className={view === "admin" ? "active" : ""} onClick={() => nav("admin")}>لوحة المدير</button>}</nav><div className="header-actions">{isLoggedIn ? <><span className="user-greeting">مرحبًا، {me.data?.name?.split(" ")[0] || "طالب"}</span><Button variant="outline" size="sm" onClick={() => logout.mutate()}><LogOut size={15} /> خروج</Button></> : <Button size="sm" onClick={() => setAuthOpen(true)}><LogIn size={15} /> دخول الطلاب</Button>}</div></div></header><main>{content}</main><footer className="site-footer"><div className="footer-inner"><BrandMark compact /><span>منصة تعليمية إلكترونية مجانية لطلاب المرحلة الثانوية في مركز البلينا</span><span>المؤسس والمدير العام: علي عمر محمد</span><span className="footer-copy">جميع الحقوق محفوظة © {new Date().getFullYear()} لمنصة طلاب البلينا</span></div></footer><PhoneLoginDialog open={authOpen} onClose={() => setAuthOpen(false)} onSuccess={() => { setAuthOpen(false); me.refetch(); }} /></div>;
}

function HomeContent({ exams, isLoggedIn, onStart, onBrowse, onLogin }: { exams: any[]; isLoggedIn: boolean; onStart: (id: number) => void; onBrowse: () => void; onLogin: () => void }) {
  return <><section className="hero-section"><div className="hero-inner"><div className="hero-copy"><span className="eyebrow"><Sparkles size={14} /> تعلم، اختبر، وتقدم</span><h1>امتحانك القادم<br /><em>يبدأ من هنا.</em></h1><p>منصة إلكترونية منظمة لطلاب البلينا تساعدك على قياس فهمك، متابعة نتائجك، والاحتفاظ بإنجازاتك في مكان واحد.</p><div className="hero-actions"><Button size="lg" onClick={onBrowse}><BookOpenCheck size={18} /> استعرض الامتحانات <ArrowLeft size={17} /></Button>{!isLoggedIn && <Button size="lg" variant="outline" onClick={onLogin}><LogIn size={17} /> تسجيل الطالب بالهاتف</Button>}</div><div className="hero-trust"><span><ShieldCheck size={16} /> نتائج محفوظة</span><span><Award size={16} /> شهادات تقدير</span><span><Users size={16} /> دخول بالاسم والرقم</span></div></div><div className="hero-visual"><div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" /><div className="hero-card-main"><div className="hero-card-top"><span>ملخص إنجازك</span><BarChart3 size={18} /></div><div className="hero-score"><strong>85%</strong><span>تقدم ثابت هذا الأسبوع</span></div><div className="mini-bars"><i style={{ height: "44%" }} /><i style={{ height: "62%" }} /><i style={{ height: "52%" }} /><i style={{ height: "78%" }} /><i style={{ height: "92%" }} /><i style={{ height: "70%" }} /></div><div className="hero-card-bottom"><span><CheckCircle2 size={14} /> 12 إجابة صحيحة</span><span>+18%</span></div></div><div className="floating-chip chip-top"><Trophy size={17} /><span><strong>إنجاز جديد</strong><small>أكملت أول امتحان</small></span></div><div className="floating-chip chip-bottom"><div className="chip-mark">ط ب</div><span><strong>أرشيفك محفوظ</strong><small>يمكنك الرجوع له دائمًا</small></span></div></div></div><div className="wave-divider" /></section><section className="feature-strip"><div><span className="feature-number">01</span><strong>اختبر فهمك</strong><small>أسئلة منظمة بزمن واضح</small></div><div><span className="feature-number">02</span><strong>راجع نتيجتك</strong><small>تصحيح ونتائج محفوظة</small></div><div><span className="feature-number">03</span><strong>احتفل بإنجازك</strong><small>شهادة تقدير قابلة للطباعة</small></div></section><LearningHub /><section className="page-shell home-exams"><SectionHeading eyebrow="اختبر مستواك" title="أحدث الامتحانات" description="اختر امتحانًا منشورًا وابدأ رحلة مراجعة واضحة." action={<Button variant="ghost" onClick={onBrowse}>عرض الكل <ArrowLeft size={16} /></Button>} />{exams.length ? <div className="exam-grid">{exams.slice(0, 3).map(exam => <ExamCard key={exam.id} exam={exam} onStart={onStart} isLoggedIn={isLoggedIn} />)}</div> : <Card className="draft-notice"><CardContent><div className="notice-icon"><PenLine size={22} /></div><div><h3>لا توجد امتحانات منشورة</h3><p>سيظهر الامتحان هنا بعد نشره من لوحة المدير.</p></div></CardContent></Card>}</section><section className="why-section"><div className="page-shell"><SectionHeading eyebrow="لماذا طلاب البلينا؟" title="كل ما تحتاجه لتعرف مستواك بوضوح" /><div className="why-grid"><div><div className="why-icon blue"><TimerReset size={21} /></div><h3>وقت واضح</h3><p>عداد بسيط يوضح الوقت المتبقي ويساعدك على تنظيم إجاباتك.</p></div><div><div className="why-icon gold"><Archive size={21} /></div><h3>أرشيف دائم</h3><p>نتائجك وإجاباتك تبقى محفوظة لتعود إليها متى احتجت.</p></div><div><div className="why-icon teal"><Award size={21} /></div><h3>شهادة تستحقها</h3><p>حوّل إنجازك إلى شهادة تقدير قابلة للطباعة والمشاركة.</p></div></div></div></section></>;
}
